import type React from "react"
import type { Metadata } from "next"
import "../styles/globals.css"

export const metadata: Metadata = {
  title: "Graneros del Sur - Productos Regionales de Argentina",
  description: "Distribuidores de productos regionales argentinos. Conectamos sabores auténticos con tu mesa.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  )
}
